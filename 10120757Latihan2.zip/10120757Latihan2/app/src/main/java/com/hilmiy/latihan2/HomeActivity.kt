package com.hilmiy.latihan2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

/** Tanggal pengerjaan : 28/04/2023
 *  Nama : Muhammad Hilmiy Muharram
 *  Nim : 10120757
 *  Kelas : IF-9 **/

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
    }
}