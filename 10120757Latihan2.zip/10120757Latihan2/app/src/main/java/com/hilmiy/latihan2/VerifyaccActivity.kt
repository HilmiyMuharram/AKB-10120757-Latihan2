package com.hilmiy.latihan2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

/** Tanggal pengerjaan : 28/04/2023
 *  Nama : Muhammad Hilmiy Muharram
 *  Nim : 10120757
 *  Kelas : IF-9 **/

class VerifyaccActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var btn_send : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verifyacc)

        btn_send = findViewById(R.id.btn_send)

        btn_send.setOnClickListener(this)
    }

    override fun onClick(p0: View) {
        when(p0.id){
            R.id.btn_send ->{
                val intent = Intent(this@VerifyaccActivity, HomeActivity::class.java)
                startActivity(intent)
            }
        }
    }
}